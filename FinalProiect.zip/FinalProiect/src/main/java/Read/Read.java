package Read;

public interface Read {

    String[] getLine(String filePath);
}
