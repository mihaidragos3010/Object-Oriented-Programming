package Observer;

public enum Event {
    DeleteStream
}
