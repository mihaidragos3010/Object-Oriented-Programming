package Observer;

import DataBase.*;

public interface Subscriber {
    void update(Stream stream);
}
